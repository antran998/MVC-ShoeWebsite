<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <link href="lib/css/style.css" type='text/css' rel='stylesheet'>
    <title>Đăng nhập</title>
</head>
<body>
    <div id="logreg-forms">
        <form class="form-signin" method="POST" action="home">
            <h1 class="h3 mb-3 font-weight-normal" style="text-align: center"> Sign in</h1>
            <div class="social-login" style="text-align: center">
                <button class="btn facebook-btn social-btn home" type="button" name="buttonHome"><span>Trang Chủ</span> </button>
            </div>
            <p style="text-align:center"> OR  </p>
            <input  id="inputEmail" class="form-control" placeholder="Tên đăng nhập" required="" autofocus="" name="usernameLogin">
            <input type="password" id="inputPassword" class="form-control" placeholder="Mật khẩu" required="" name="passwordLogin">
            
            <button class="btn btn-success btn-block" type="submit" name="login"><i class="fas fa-sign-in-alt"></i> Sign in</button>
            <a href="#" id="forgot_pswd">Forgot password?</a>
            <hr>
            <!-- <p>Don't have an account!</p>  -->
            <button class="btn btn-primary btn-block" type="button" id="btn-signup"><i class="fas fa-user-plus"></i> Sign up New Account</button>
        </form>

        <form action="/reset/password/" class="form-reset">
            <input type="email" id="resetEmail" class="form-control" placeholder="Email address" required="" autofocus="">
            <button class="btn btn-primary btn-block" type="submit">Reset Password</button>
            <a href="#" id="cancel_reset"><i class="fas fa-angle-left"></i> Back</a>
        </form>
        <form action="" class="form-signup" method="POST">
            <div class="social-login">
                <button class="btn facebook-btn social-btn" type="button"><span><i class="fab fa-facebook-f"></i> Sign up with Facebook</span> </button>
            </div>
            <div class="social-login">
                <button class="btn google-btn social-btn" type="button"><span><i class="fab fa-google-plus-g"></i> Sign up with Google+</span> </button>
            </div>
            
            <p style="text-align:center">OR</p>

            <input type="text" id="user-name" class="form-control" placeholder="Tên tài khoản" required="" autofocus="" name="username">
            <input type="password" id="user-pass" class="form-control" placeholder="Mật khẩu" required autofocus="" name="pass">
            <input type="password" id="user-repeatpass" class="form-control" placeholder="Nhập lại mật khẩu" required autofocus="" name="pass-repeat">
            <input type="text" id="fullname" class="form-control" placeholder="Họ tên"  autofocus="" name="fullname">
            <input type="text" id="email" class="form-control" placeholder="Email"  autofocus="" name="email">
            <input type="text" id="address" class="form-control" placeholder="Địa chỉ"  autofocus="" name="address">
            <input type="text" id="phone" class="form-control" placeholder="Số điện thoại"  autofocus="" name="phonenum">
            <button class="btn btn-primary btn-block Registry" type="submit" name="btn_submit"><i class="fas fa-user-plus"></i> Sign Up</button>
            <a href="#" id="cancel_signup"><i class="fas fa-angle-left"></i> Back</a>
        </form>
        <br>
            
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <?php 
        if(isset($_SESSION['check'])){
            unset($_SESSION['check']);
            echo "<script type='text/javascript'>alert('Sai tên đăng nhập hoặc mật khẩu')</script>";
        }
    ?>
    <script type="text/javascript" src="lib/js/signAccount.js"></script>
    <script type="text/javascript" src="lib/js/addUser.js"></script>
    
</body>
</html>