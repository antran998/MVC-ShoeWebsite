<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quản lý tài khoản </title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="lib/css/CRUD.css">
<link rel="stylesheet" type="text/css" href="lib/css/style.css">

</head>
<body >
	
	<div class="header-area">
        <div class="container align-user">            
            <ul class="list-unstyled list-inline">
                <?php
                if(!isset($_SESSION['username'])){
                    echo 
                    '<li><a href="addUser"><i class="fa fa-sign-in"></i> Đăng nhập</a></li>
                    <li><a onclick="signUpClick();"><i class="fa fa-pencil"></i> Đăng ký</a></li>';              
                }
                else{
                    echo 
                    '<li><a href="home"><i class="fa fa-home"></i> Trang chủ</a></li>
                    ';
                    if(strpos($_SESSION['id'], 'AD') !== false){
                        echo
                        '<li><a href="CRUDAccount"><i class="fa fa-user"></i> Thành viên</a></li>
                        <li><a href="CRUDItem"><i class="fa fa-archive"></i> Kho hàng</a></li>
                        <li><a target="_blank" href="https://app.subiz.com/activities/usqjeywtdruzvhfgvnjpt/convo/csqjeywujpojwcdifh"><i class="fa fa-comments"></i> Tin nhắn</a></li>
                        ';
                    }                         
                    echo 
                    '<li><a href="accountInfo" target="_blank"><i class="fa fa-info-circle"></i> '.$_SESSION['username'].'</a></li>
                    <li><form action="" class="form-signup" method="POST">
                        <button type="submit" name="logout" id="logout">LogOut</button>
                    </form></li>';
                }
                ?>
            </ul>                    
        </div>
    </div> <!-- End header area -->

    <div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
						<h2>Quản lý  <b>Account</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Add New Account</span></a>
						<a href="#deleteEmployeeModal" class="btn btn-danger" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Delete</span></a>						
					</div>
                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
						<th>
							
						</th>
                        <th>ID</th>
                        <th>Họ tên</th>
						<th>Địa chỉ Email</th>
                        <th>Địa chỉ</th>
                        <th>Số điện thoại</th>
                        <th>Thao tác</th>
                        
                    </tr>
                </thead>
                <tbody id="data">
					
                    <?php

	                   $data=$GLOBALS['db']->ReturnListValue('account_info');
	                
	                    
	                    while($row=mysqli_fetch_assoc($data)){
	                        echo '<tr>
							<td>
								
							</td>
	                        <td id="ID" name='.$row['ID'].'>'.$row['ID'].'</td>
	                        <td>'.$row['FULL_NAME'].'</td>
							<td>'.$row['EMAIL'].'</td>
	                        <td>'.$row['ADDRESS'].'</td>
	                        <td>'.$row['PHONE'].'</td>
							<td>
							
	                            <a href="#editEmployeeModal"  class="edit getIDeditAcc" data-toggle="modal"  acc-id="'.$row['ID'].'"><i  class="material-icons" data-toggle="tooltip" title="Edit"  >&#xE254;</i></a>
	                            <a href="#deleteEmployeeModal" class="delete getIDdeleteAcc" data-toggle="modal"  acc-id="'.$row['ID'].'"><i class="material-icons" data-toggle="tooltip" title="Delete" >&#xE872;</i></a>
							</td>
	                        </tr>';
	                    }
                    ?>
                    
                </tbody>
            </table>
			<div class="clearfix">
                <div class="hint-text">Showing <b>5</b> out of <b>25</b> entries</div>
                <ul class="pagination">
                    <li class="page-item disabled"><a href="#">Previous</a></li>
                    <li class="page-item"><a href="#" class="page-link">1</a></li>
                    <li class="page-item"><a href="#" class="page-link">2</a></li>
                    <li class="page-item active"><a href="#" class="page-link">3</a></li>
                    <li class="page-item"><a href="#" class="page-link">4</a></li>
                    <li class="page-item"><a href="#" class="page-link">5</a></li>
                    <li class="page-item"><a href="#" class="page-link">Next</a></li>
                </ul>
            </div>
        </div>
    </div>
	<!-- Add Modal HTML -->
	
	<div id="addEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
					
				<form action="" method="POST" onSubmit="window.reload()" enctype="multipart/form-data"> 
					<div class="modal-header">						
						<h4 class="modal-title">Thêm tài khoản</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">					
						<div class="form-group">
							<label>ID</label>
							<input type="text" id="idInsertAcc" class="form-control" name="id" required>
						</div>
						<div class="form-group">
							<label>Tên tài khoản</label>
							<input type="text" id="nameInsertAcc" class="form-control"  name="name" required>
						</div>
						<div class="form-group">
							<label>Họ tên</label>
							<input type="text" id="fullnameInsertAcc" class="form-control"  name="fullname" required>
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="text" id="emailInsertAcc" class="form-control"  name="email" required>
						</div>
						<div class="form-group">
							<label>Địa chỉ</label>
							<input type="text" id="addressInsertAcc" class="form-control"  name="address" >
						</div>	
                        <div class="form-group">
							<label>Số điện thoại</label>
							<input type="text" class="form-control" id="phoneInsertAcc" name="phone" >
						</div>							
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<input type="submit" class="btn btn-success insertAcc" value="Add"  name="insertSubmit">
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Edit Modal HTML -->
    
    <div id="editEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form>
					<div class="modal-header">						
						<h4 class="modal-title">Edit item</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">					
						
						<div class="form-group">
							<label>Họ tên</label>
							<input type="text" class="form-control" id="fullnameEditAcc" required>
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="text" class="form-control" id="emailEditAcc" required>
						</div>
						<div class="form-group">
							<label>Địa chỉ</label>
							<input type="text"  class="form-control" id="addressEditAcc" required>
						</div>
						<div class="form-group">
							<label>Số điện thoại</label>
							<input type="text" class="form-control" id="phoneEditAcc" required>
						</div>					
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<input type="submit" class="btn btn-info Edit" value="Save">
					</div>
				</form>
			</div>
		</div>
	</div>
	
	<!-- Delete Modal HTML -->
	<div id="deleteEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
			
				<form method="POST" onSubmit="window.reload()">
					<div class="modal-header">						
						<h4 class="modal-title">Delete item</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">					
						<p>Are you sure you want to delete these Records?</p>
						<p class="text-warning"><small>This action cannot be undone.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<input type="submit" class="btn btn-danger " value="Delete" name="deleteItem">
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="final"></div>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="lib/js/CRUDaccount.js"></script>
</html>